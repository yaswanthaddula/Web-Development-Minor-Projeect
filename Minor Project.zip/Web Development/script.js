// Get DOM elements
const form = document.getElementById('crudForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const dataList = document.getElementById('dataList');
const submitBtn = document.getElementById('submitBtn');

let editIndex = -1; // Track index for updating

// Load data from localStorage
let users = JSON.parse(localStorage.getItem('users')) || [];
renderData();

// Handle form submit
form.addEventListener('submit', function(e) {
    e.preventDefault();
    const name = nameInput.value.trim();
    const email = emailInput.value.trim();

    if(editIndex >= 0) {
        // Update existing record
        users[editIndex] = { name, email };
        editIndex = -1;
        submitBtn.textContent = "Add";
    } else {
        // Add new record
        users.push({ name, email });
    }

    localStorage.setItem('users', JSON.stringify(users));
    form.reset();
    renderData();
});

// Render table data
function renderData() {
    dataList.innerHTML = '';
    users.forEach((user, index) => {
        const tr = document.createElement('tr');

        tr.innerHTML = `
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>
                <button class="edit" onclick="editData(${index})">Edit</button>
                <button class="delete" onclick="deleteData(${index})">Delete</button>
            </td>
        `;

        dataList.appendChild(tr);
    });
}

// Edit function
function editData(index) {
    nameInput.value = users[index].name;
    emailInput.value = users[index].email;
    submitBtn.textContent = "Update";
    editIndex = index;
}

// Delete function
function deleteData(index) {
    if(confirm("Are you sure you want to delete this record?")) {
        users.splice(index, 1);
        localStorage.setItem('users', JSON.stringify(users));
        renderData();
    }
}
